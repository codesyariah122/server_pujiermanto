/* (C) 2008  The Measurement Factory */

#ifndef ECAP_ADAPTER_SAMPLE_H
#define ECAP_ADAPTER_SAMPLE_H

// this file should be included first from all sample sources

#ifdef HAVE_CONFIG_H
#include "autoconf.h"
#endif

#endif /* ECAP_ADAPTER_SAMPLE_H */
